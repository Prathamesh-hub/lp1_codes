# graph = {
# 	'A':['B', 'C', 'D'], 'B':['E'], 'C':['D', 'E'], 'D':[], 'E':[]
# }

Graph = {}
num_nodes = int(input('Enter number of nodes'))
for i in range(num_nodes):
	node = input('Enter node{}:'.format(i+1))
	num_neighbours =int( input('Enter number of neighbours'))
	ls = []
	for j in range(num_neighbours):
		neighbour = input('enter neighbour {}:'.format(j+1))
		ls.append(neighbour)
	Graph[node] = ls
visited = set()

def dfs(visited, graph, root):
	if root not in visited:
		print(root)
		visited.add(root)
		for neighbour in graph[root]:
			dfs(visited, graph, neighbour)
		

dfs(visited, Graph, 'A')
